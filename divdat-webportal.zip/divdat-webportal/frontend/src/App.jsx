import '../styles/App.css'

import Navbar from '../components/Navbar'

function App() {
  return (
    <div className='container mx-auto lg:px-48 sm:px-6 px-6' id='main'>
      <Navbar />
      <p className='underline text-4xl'>Hello TailWind</p>

      <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
      Nunc commodo diam a ex accumsan, luctus tincidunt sem tristique. 
      Curabitur nunc dolor, cursus in quam a, facilisis sagittis arcu. 
      Proin id egestas erat. Pellentesque et urna nisl. Fusce non elit 
      finibus, vehicula diam sed, tincidunt risus. Aliquam nec sapien at 
      nibh dictum pulvinar in eu magna. Ut et varius tellus. Vestibulum 
      posuere urna at imperdiet lobortis. Quisque quis tempor odio. 
      </p>
      
      <p>
      Cras fermentum porttitor odio. Nullam a ultrices ante. In maximus 
      metus sit amet odio venenatis, a consequat leo aliquet. Fusce 
      porttitor nunc tortor, in efficitur sem molestie vitae. Lorem ipsum 
      dolor sit amet, consectetur adipiscing elit. Nulla mollis quam 
      sollicitudin efficitur ultricies. Maecenas nec nibh at lectus venenatis 
      ultrices. Phasellus lacus urna, ullamcorper vel enim et, vulputate 
      sodales sapien. Donec tortor ipsum, finibus quis justo eu, pharetra 
      tincidunt massa. Morbi posuere vehicula dapibus. Donec molestie felis 
      sit amet risus luctus ultrices. Donec pellentesque congue tincidunt. 
      Cras eu placerat diam, ullamcorper vestibulum mauris. Suspendisse sed 
      molestie augue. Ut vulputate augue id felis vulputate, sit amet tempus 
      metus dignissim. 
      </p>

    </div>
  )
}

export default App