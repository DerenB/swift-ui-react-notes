import '../styles/Navbar.css'

function Navbar() {
    return (
        <nav className="navbarMain">
            <div className="logo">
                <img src="../assets/logo.png" alt="" />
            </div>
            <div className="nav-link">
                <a href="/">Home</a>
                <a href="#">About</a>
            </div>
        </nav>
    )
}

export default Navbar